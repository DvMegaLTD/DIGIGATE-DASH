/*
 * M0FXB HamTech Dashboard — V8 interaction layer
 *
 * Live Node Activity represents link commands issued from this dashboard.
 * It does not independently poll Asterisk for out-of-band link changes.
 */

(() => {
    'use strict';

    const statusLine = document.getElementById('system-status');

    const heartbeatTrace = document.getElementById('heartbeat-trace');
    const heartbeatHead = document.getElementById('heartbeat-head');
    const heartbeatState = document.getElementById('heartbeat-state');
    const heartbeatMode = document.getElementById('heartbeat-mode');

    const liveTitle = document.getElementById('live-title');
    const liveSubtitle = document.getElementById('live-subtitle');
    const liveState = document.getElementById('live-state');
    const activityBars = Array.from(document.querySelectorAll('#activity-meter span'));

    const lastActionTitle = document.getElementById('last-action-title');
    const lastActionSubtitle = document.getElementById('last-action-subtitle');

    const actionKeys = Array.from(document.querySelectorAll('.key-action'));
    const linkKeys = Array.from(document.querySelectorAll('[data-kind="link"]'));
    const externalKeys = Array.from(document.querySelectorAll('.key-link'));
    const allKeys = [...actionKeys, ...externalKeys];

    let activeLinkKey = null;

    // Heartbeat sweep state.
    let heartbeatActive = false;
    let sweepX = 360;
    let sweepPoints = [];
    let lastFrame = performance.now();

    function localTime() {
        return new Date().toLocaleTimeString([], {
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit'
        });
    }

    function setSystemStatus(message, isError = false) {
        statusLine.textContent = `▶ ${message}`;
        statusLine.classList.toggle('error', isError);
    }

    function setLastAction(title, detail) {
        lastActionTitle.textContent = title;
        lastActionSubtitle.textContent = `${localTime()} · ${detail}`;
    }

    function setKeyActive(key, active) {
        key.classList.toggle('is-active', active);
        if (key.matches('button')) {
            key.setAttribute('aria-pressed', active ? 'true' : 'false');
        }
    }

    function flashKeyLed(key, duration = 650) {
        setKeyActive(key, true);
        window.clearTimeout(key.__ledTimer);
        key.__ledTimer = window.setTimeout(() => {
            if (key.dataset.kind !== 'link') {
                setKeyActive(key, false);
            }
        }, duration);
    }

    function setHeartbeat(active) {
        heartbeatActive = active;
        heartbeatTrace.classList.toggle('active', active);
        heartbeatTrace.classList.toggle('idle', !active);
        heartbeatHead.classList.toggle('active', active);
        heartbeatHead.classList.toggle('idle', !active);
        heartbeatState.textContent = active ? 'ACTIVE' : 'READY';
        heartbeatMode.textContent = active ? 'LINK ACTIVE' : 'IDLE';

        // Restart the trace from the right whenever the state changes.
        sweepX = 360;
        sweepPoints = [];
    }

    function lerp(a, b, t) {
        return a + (b - a) * t;
    }

    /*
     * ECG shape tied to the sweep's x-position.
     * The trace travels right-to-left and physically rises/dips as it crosses
     * the centre of the heartbeat pod.
     */
    function pulseY(x, active) {
        const base = 28;
        const scale = active ? 1 : 0.38;

        if (x > 218 || x < 142) {
            return base;
        }

        if (x >= 206) {
            const t = (218 - x) / 12;
            return base - 5 * scale * Math.sin(Math.PI * t);
        }

        if (x >= 196) {
            const t = (206 - x) / 10;
            return lerp(base, base + 7 * scale, t);
        }

        if (x >= 184) {
            const t = (196 - x) / 12;
            return lerp(base + 7 * scale, base - 19 * scale, t);
        }

        if (x >= 174) {
            const t = (184 - x) / 10;
            return lerp(base - 19 * scale, base + 18 * scale, t);
        }

        if (x >= 162) {
            const t = (174 - x) / 12;
            return lerp(base + 18 * scale, base - 9 * scale, t);
        }

        if (x >= 150) {
            const t = (162 - x) / 12;
            return lerp(base - 9 * scale, base, t);
        }

        const t = (150 - x) / 8;
        return base + 2 * scale * Math.sin(Math.PI * t);
    }

    function animateHeartbeat(now) {
        const dt = Math.min(50, now - lastFrame);
        lastFrame = now;

        // Slow, occasional idle pulse; quicker repeating active pulse.
        const speed = heartbeatActive ? 165 : 62;
        sweepX -= speed * (dt / 1000);

        if (sweepX <= 0) {
            sweepX = 360;
            sweepPoints = [];
        }

        const y = pulseY(sweepX, heartbeatActive);
        sweepPoints.push([sweepX, y]);

        heartbeatTrace.setAttribute(
            'points',
            sweepPoints.map(([x, pointY]) => `${x.toFixed(1)},${pointY.toFixed(1)}`).join(' ')
        );

        heartbeatHead.setAttribute('cx', sweepX.toFixed(1));
        heartbeatHead.setAttribute('cy', y.toFixed(1));

        window.requestAnimationFrame(animateHeartbeat);
    }

    function setActivityMeter(level) {
        activityBars.forEach((bar, index) => {
            if (index < level) {
                if (index < 8) {
                    bar.style.background = '#4d6a42';
                } else if (index < 14) {
                    bar.style.background = '#6f944f';
                } else {
                    bar.style.background = '#9cc96b';
                }
                bar.style.transform = `scaleY(${1 + ((index % 4) * 0.08)})`;
                bar.style.opacity = '1';
            } else {
                bar.style.background = '#2d352c';
                bar.style.transform = 'scaleY(1)';
                bar.style.opacity = '0.72';
            }
        });
    }

    function setDisconnected() {
        liveTitle.textContent = 'DISCONNECTED';
        liveSubtitle.textContent = 'No active node links · dashboard ready';
        liveState.textContent = 'IDLE';
        setActivityMeter(1);
        setHeartbeat(false);
    }

    function setConnected(key) {
        const displayTitle = key.dataset.title.replace(/^Link\s+/i, '');
        liveTitle.textContent = displayTitle;
        liveSubtitle.textContent = `Connected · ${key.dataset.code}`;
        liveState.textContent = 'ACTIVE';
        setActivityMeter(17);
        setHeartbeat(true);
    }

    async function runCommand(keyName, mode = 'execute') {
        const params = new URLSearchParams({
            cmd: keyName,
            mode
        });

        const response = await fetch(`control.php?${params.toString()}`, {
            method: 'GET',
            credentials: 'same-origin',
            headers: {
                'Accept': 'application/json'
            }
        });

        let payload = null;
        try {
            payload = await response.json();
        } catch {
            payload = null;
        }

        if (!response.ok || !payload || payload.ok !== true) {
            const message = payload && payload.error
                ? payload.error
                : `Command failed (${response.status})`;
            throw new Error(message);
        }

        return payload;
    }

    async function handleLinkKey(key) {
        const isCurrent = activeLinkKey === key;

        key.disabled = true;
        try {
            if (isCurrent) {
                setSystemStatus(`DISCONNECTING ${key.dataset.title.toUpperCase()}…`);
                await runCommand(key.dataset.key, 'disconnect');

                setKeyActive(key, false);
                activeLinkKey = null;
                setDisconnected();
                setLastAction(key.dataset.title, `Link disconnected · ${key.dataset.code}`);
                setSystemStatus(`${key.dataset.title.toUpperCase()} · LINK DISCONNECTED`);
                return;
            }

            if (activeLinkKey) {
                const previousKey = activeLinkKey;
                setSystemStatus(`SWITCHING FROM ${previousKey.dataset.title.toUpperCase()}…`);
                await runCommand(previousKey.dataset.key, 'disconnect');
                setKeyActive(previousKey, false);
                activeLinkKey = null;
            }

            setSystemStatus(`CONNECTING ${key.dataset.title.toUpperCase()}…`);
            await runCommand(key.dataset.key, 'execute');

            activeLinkKey = key;
            linkKeys.forEach((linkKey) => setKeyActive(linkKey, linkKey === key));
            setConnected(key);
            setLastAction(key.dataset.title, `Link connected · ${key.dataset.code}`);
            setSystemStatus(`${key.dataset.title.toUpperCase()} · LINK ACTIVE`);
        } catch (error) {
            if (!activeLinkKey) {
                setDisconnected();
            }
            setLastAction(key.dataset.title, `ERROR · ${error.message}`);
            setSystemStatus(`ERROR · ${error.message}`, true);
        } finally {
            key.disabled = false;
        }
    }

    async function handleDisconnectAll(key) {
        key.disabled = true;
        flashKeyLed(key, 700);

        try {
            setSystemStatus('DISCONNECTING ALL LINKS…');
            await runCommand(key.dataset.key, 'execute');

            linkKeys.forEach((linkKey) => setKeyActive(linkKey, false));
            activeLinkKey = null;
            setDisconnected();
            setLastAction('Disconnect All', 'All active links cleared');
            setSystemStatus('DISCONNECT ALL · SYSTEM RETURNED TO IDLE');
        } catch (error) {
            setLastAction('Disconnect All', `ERROR · ${error.message}`);
            setSystemStatus(`ERROR · ${error.message}`, true);
        } finally {
            key.disabled = false;
        }
    }

    async function handleMomentaryAction(key) {
        flashKeyLed(key);

        try {
            setSystemStatus(`SENDING ${key.dataset.title.toUpperCase()}…`);
            await runCommand(key.dataset.key, 'execute');

            let detail = 'Command executed';
            if (key.dataset.title === 'Parrot On') {
                detail = 'Parrot audio mode enabled';
            } else if (key.dataset.title === 'Parrot Off') {
                detail = 'Parrot audio mode disabled';
            } else if (key.dataset.title === 'Audio Test') {
                detail = `Audio test triggered · ${key.dataset.code}`;
            }

            // Action buttons update Last Action only.
            setLastAction(key.dataset.title, detail);
            setSystemStatus(`${key.dataset.title.toUpperCase()} · ${detail.toUpperCase()}`);
        } catch (error) {
            setLastAction(key.dataset.title, `ERROR · ${error.message}`);
            setSystemStatus(`ERROR · ${error.message}`, true);
        }
    }

    function handleExternalAction(key) {
        flashKeyLed(key);
        setLastAction(key.dataset.title, 'External view opened');
        setSystemStatus(`${key.dataset.title.toUpperCase()} · EXTERNAL VIEW OPENED`);
    }

    function addPressFeedback(key) {
        const press = () => {
            key.classList.add('is-pressed');
            if ('vibrate' in navigator) {
                navigator.vibrate(10);
            }
        };

        const release = () => {
            key.classList.remove('is-pressed');
        };

        key.addEventListener('pointerdown', press);
        key.addEventListener('pointerup', release);
        key.addEventListener('pointercancel', release);
        key.addEventListener('pointerleave', release);
    }

    allKeys.forEach(addPressFeedback);

    actionKeys.forEach((key) => {
        key.addEventListener('click', () => {
            if (key.dataset.kind === 'link') {
                handleLinkKey(key);
            } else if (key.dataset.kind === 'disconnect-all') {
                handleDisconnectAll(key);
            } else {
                handleMomentaryAction(key);
            }
        });
    });

    externalKeys.forEach((key) => {
        key.addEventListener('click', () => {
            handleExternalAction(key);
        });
    });

    linkKeys.forEach((key) => setKeyActive(key, false));
    setDisconnected();
    setActivityMeter(1);
    window.requestAnimationFrame(animateHeartbeat);
})();
