<?php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');

$buttons = parse_ini_file('buttons.ini', true);
$config = parse_ini_file('config.ini', true);

$nodeNumber = isset($config['node']['number']) ? (string)$config['node']['number'] : '';

function respond(int $status, array $payload): void {
    http_response_code($status);
    echo json_encode($payload);
    exit;
}

function run_asterisk_command(string $nodeNumber, string $command): void {
    if (!ctype_digit($nodeNumber)) {
        throw new RuntimeException('Invalid node number.');
    }

    if (strpos($command, 'cop:') === 0) {
        $cop = substr($command, 4);
        if (!ctype_digit($cop)) {
            throw new RuntimeException('Invalid COP command.');
        }
        $asteriskCommand = "rpt cmd {$nodeNumber} cop {$cop}";
    } else {
        if (!preg_match('/^\*[0-9]+$/', $command)) {
            throw new RuntimeException('Invalid DTMF command.');
        }
        $asteriskCommand = "rpt fun {$nodeNumber} {$command}";
    }

    $shellCommand = 'sudo /usr/sbin/asterisk -rx ' . escapeshellarg($asteriskCommand);
    shell_exec($shellCommand);
}

if (!isset($_GET['cmd'])) {
    respond(400, ['ok' => false, 'error' => 'Missing command key.']);
}

$key = (string)$_GET['cmd'];
$mode = isset($_GET['mode']) ? (string)$_GET['mode'] : 'execute';

if (!isset($buttons[$key])) {
    respond(404, ['ok' => false, 'error' => 'Unknown command key.']);
}

$button = $buttons[$key];
$commands = isset($button['cmds']) ? array_values((array)$button['cmds']) : [];

if ($mode === 'disconnect') {
    $color = strtolower((string)($button['color'] ?? ''));

    if ($color !== 'green' || count($commands) !== 1 || !preg_match('/^\*3([0-9]+)$/', $commands[0], $match)) {
        respond(400, ['ok' => false, 'error' => 'This control is not a disconnectable node link.']);
    }

    // AllStar standard: *3<node> connects/transceives, *1<node> disconnects.
    $disconnectCommand = '*1' . $match[1];

    try {
        run_asterisk_command($nodeNumber, $disconnectCommand);
        respond(200, [
            'ok' => true,
            'mode' => 'disconnect',
            'key' => $key,
            'command' => $disconnectCommand
        ]);
    } catch (Throwable $error) {
        respond(500, ['ok' => false, 'error' => $error->getMessage()]);
    }
}

if ($mode !== 'execute') {
    respond(400, ['ok' => false, 'error' => 'Unsupported command mode.']);
}

if (!$commands) {
    respond(400, ['ok' => false, 'error' => 'This control has no executable command.']);
}

try {
    foreach ($commands as $command) {
        run_asterisk_command($nodeNumber, (string)$command);
    }

    respond(200, [
        'ok' => true,
        'mode' => 'execute',
        'key' => $key,
        'commands' => $commands
    ]);
} catch (Throwable $error) {
    respond(500, ['ok' => false, 'error' => $error->getMessage()]);
}
