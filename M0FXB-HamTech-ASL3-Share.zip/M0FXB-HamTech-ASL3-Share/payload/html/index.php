<?php
$config = parse_ini_file('config.ini', true);
$nodeNumber = isset($config['node']['number']) ? (string)$config['node']['number'] : '59398';
$nodeTitle = isset($config['node']['title']) ? (string)$config['node']['title'] : 'M0FXB';

$buttons = parse_ini_file('buttons.ini', true);

function h($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function command_list($button) {
    if (!isset($button['cmds'])) {
        return [];
    }
    return array_values((array)$button['cmds']);
}

function button_kind($key, $button) {
    if ($key === 'disconnect_all') {
        return 'disconnect-all';
    }

    if (isset($button['href'])) {
        return 'external';
    }

    $color = strtolower((string)($button['color'] ?? 'blue'));
    $commands = command_list($button);

    if ($color === 'green' && count($commands) === 1 && preg_match('/^\*3\d+$/', $commands[0])) {
        return 'link';
    }

    return 'action';
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo h($nodeTitle); ?> | HamTech Node <?php echo h($nodeNumber); ?></title>
    <meta name="description" content="<?php echo h($nodeTitle); ?> - AllStarLink HamTech control dashboard">
    <meta name="robots" content="noindex, nofollow">
    <link rel="stylesheet" href="style.css">
    <script defer src="dashboard.js"></script>
</head>
<body>
    <main class="dashboard-shell">
        <header class="dashboard-header">
            <div class="brand">
                <h1>M0FXB HamTech Dashboard</h1>
            </div>

            <section class="heartbeat-panel" aria-label="Link heartbeat status">
                <div class="heartbeat-meta">
                    <span>NODE <?php echo h($nodeNumber); ?></span>
                    <span>FM-ASL</span>
                    <span id="heartbeat-state">READY</span>
                </div>

                <div class="heartbeat-graph">
                    <svg class="heartbeat-svg" viewBox="0 0 360 56" preserveAspectRatio="none" aria-hidden="true">
                        <defs>
                            <clipPath id="heartbeat-clip">
                                <rect x="0" y="0" width="360" height="56" rx="8" ry="8"></rect>
                            </clipPath>
                        </defs>
                        <path class="heartbeat-baseline" d="M0 28 H360"></path>
                        <polyline id="heartbeat-trace" class="heartbeat-trace idle" clip-path="url(#heartbeat-clip)" points=""></polyline>
                        <circle id="heartbeat-head" class="heartbeat-head idle" cx="360" cy="28" r="3"></circle>
                    </svg>
                </div>

                <div class="heartbeat-mode" id="heartbeat-mode">IDLE</div>
            </section>
        </header>

        <section class="status-grid">
            <section class="status-pod live-pod" aria-labelledby="live-node-heading">
                <h2 id="live-node-heading">Live Node Activity</h2>

                <div class="live-row">
                    <div class="live-copy">
                        <div class="live-title" id="live-title">DISCONNECTED</div>
                        <div class="live-subtitle" id="live-subtitle">No active node links · Node <?php echo h($nodeNumber); ?> ready</div>
                    </div>

                    <div class="live-state">
                        <span>LINK STATE</span>
                        <strong id="live-state">IDLE</strong>
                    </div>
                </div>

                <div class="activity-meter" id="activity-meter" aria-hidden="true">
                    <?php for ($i = 0; $i < 20; $i++): ?>
                        <span></span>
                    <?php endfor; ?>
                </div>
            </section>

            <section class="status-pod last-action-pod" aria-labelledby="last-action-heading">
                <h2 id="last-action-heading">Last Action</h2>
                <div class="last-action-title" id="last-action-title">None yet</div>
                <div class="last-action-subtitle" id="last-action-subtitle">Awaiting button press</div>
            </section>
        </section>

        <section class="controls-section">
            <div class="controls-heading">
                <h2>Memory Channels &amp; Function Keys</h2>
                <p>Tap a key to operate the dashboard.</p>
            </div>

            <div class="button-grid">
                <?php
                $channelIndex = 1;
                foreach ($buttons as $key => $button):
                    $title = isset($button['title']) ? (string)$button['title'] : (string)$key;
                    $color = strtolower((string)($button['color'] ?? 'blue'));
                    $commands = command_list($button);
                    $commandLabel = isset($button['href']) ? 'EXT' : implode(' · ', $commands);
                    $kind = button_kind($key, $button);
                    $channel = sprintf('%02d', $channelIndex++);
                ?>
                    <?php if ($kind === 'external'): ?>
                        <a
                            class="radio-key color-<?php echo h($color); ?> key-link"
                            href="<?php echo h($button['href']); ?>"
                            target="_blank"
                            rel="noopener noreferrer"
                            id="<?php echo h($key); ?>"
                            data-key="<?php echo h($key); ?>"
                            data-kind="<?php echo h($kind); ?>"
                            data-color="<?php echo h($color); ?>"
                            data-title="<?php echo h($title); ?>"
                            data-code="EXT"
                            aria-label="<?php echo h($title); ?>"
                        >
                            <span class="key-meta">
                                <span><?php echo h($channel); ?></span>
                                <span>EXT</span>
                            </span>
                            <span class="key-label"><?php echo h($title); ?></span>
                            <span class="key-led" aria-hidden="true"></span>
                        </a>
                    <?php else: ?>
                        <button
                            type="button"
                            class="radio-key color-<?php echo h($color); ?> key-action"
                            id="<?php echo h($key); ?>"
                            data-key="<?php echo h($key); ?>"
                            data-kind="<?php echo h($kind); ?>"
                            data-color="<?php echo h($color); ?>"
                            data-title="<?php echo h($title); ?>"
                            data-code="<?php echo h($commandLabel); ?>"
                            aria-pressed="false"
                        >
                            <span class="key-meta">
                                <span><?php echo h($channel); ?></span>
                                <?php if ($commandLabel !== ''): ?>
                                    <span><?php echo h($commandLabel); ?></span>
                                <?php endif; ?>
                            </span>
                            <span class="key-label"><?php echo h($title); ?></span>
                            <span class="key-led" aria-hidden="true"></span>
                        </button>
                    <?php endif; ?>
                <?php endforeach; ?>
            </div>
        </section>

        <div class="system-status" id="system-status" role="status" aria-live="polite">
            ▶ SYSTEM READY · NO ACTIVE LINKS
        </div>
    </main>
</body>
</html>
